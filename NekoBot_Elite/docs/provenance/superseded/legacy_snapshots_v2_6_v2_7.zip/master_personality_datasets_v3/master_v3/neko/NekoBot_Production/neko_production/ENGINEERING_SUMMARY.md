# Engineering Summary — Neko Bot Fix (2026-09-22)

## Symptom
Every message the bot received triggered the global error reply:

> Something went sideways inside Neko. The error is logged.

This is the user-facing text from `bot/core/bot.py` → `global_error_handler` when any unhandled exception escapes a handler.

## Root Cause
The personality layer (enabled by default in DMs) runs on nearly every non-command text message. Two data loaders used **cwd-relative** paths:

| Component | Old path | Problem |
|-----------|----------|---------|
| `SkinLoader` (`bot/personality/personality.py`) | `"data/personality/skins"` | Only works if process CWD is project root |
| Few-shot bank (`bot/personality/examples.py`) | `"data/personality/dataset/fewshot_bank.json"` | Same |

When the bot is started under systemd, Docker with a different `WORKDIR`, or `python -m` from another directory, those files are not found. `SkinLoader.load()` fell back to `neko.json`, then did an unguarded `path.read_text()`, raising `FileNotFoundError`. That exception was **not** caught in `handle_message` / `generate_direct` / `rewrite`, so it bubbled to the global handler and produced the message on every send.

Other loaders (jokes, custom-instruction presets) already used `settings.data_dir` and were unaffected.

## Changes (no feature loss, no regressions)

### 1. Path resolution (correctness)
- `SkinLoader` now resolves against `settings.data_dir / "personality" / "skins"`.
- Few-shot bank uses `settings.data_dir / "personality" / "dataset" / "fewshot_bank.json"`.
- Aligns with jokes, presets, and the rest of the project.

### 2. Defensive skin load (availability)
- If even the fallback `neko.json` is missing, `SkinLoader` returns a minimal safe skin instead of crashing.
- Logging is explicit so operators can see a misconfigured data directory.

### 3. Personality message handler (isolation)
- Generation / rewrite / subplugin routing is wrapped in try/except inside `handle_message`.
- A future personality bug can no longer spam the global “sideways” reply; it is logged and the update is skipped for that path only.

### 4. ChatMemberStatus consistency (compatibility)
- Two remaining uses of the pre-v20 name `ChatMemberStatus.CREATOR` were updated to `ChatMemberStatus.OWNER` (python-telegram-bot ≥ 20).
  - `bot/plugins/personality.py` (`_is_admin`)
  - `bot/plugins/music_live.py` (music control permission check)
- No behavior change: both constants map to the same Telegram status `'creator'`.

## What was **not** changed
- All plugins, middleware, models, database schema, commands, economy, music, collector, federations, automod, fonts, reactions, dashboard, tests, Docker, CI, and data assets (skins, presets, few-shot bank, jokes) are intact.
- No public API, command set, or config surface was altered.
- No dependency versions were bumped.
- Default personality behavior (DM on / group off, skins, cooldowns, limits) is unchanged when data files are present.

## Deploy notes
1. Unpack over an existing install or use this tree as the new source of truth.
2. Ensure `DATA_DIR` (default `./data`) contains `personality/skins/neko.json` (and the rest of the skins/presets/dataset shipped in this archive).
3. Restart the process (or rebuild the image). No migration step required.
4. If the error persists, inspect structured logs for `unhandled_update_error` or `personality_generate_failed` — the user-facing text deliberately hides internals.

## Files touched
- `bot/personality/personality.py` — SkinLoader path + safe fallback
- `bot/personality/examples.py` — few-shot path
- `bot/plugins/personality.py` — try/except around generate + CREATOR→OWNER
- `bot/plugins/music_live.py` — CREATOR→OWNER

## Verification checklist
- [ ] Bot starts without import errors
- [ ] DM text message gets a personality reply (or silence if cooldown/limit), **not** the sideways message
- [ ] Group messages with personality off behave as before
- [ ] `/play`, admin checks, fonts, economy XP still work
- [ ] Logs show no `FileNotFoundError` for skins when CWD ≠ project root

---

## Identity protection & anime dual-source (2026-09-23)

### AI identity rules (`bot/plugins/ai.py`)
- System prompt always includes an identity guard: no provider/model/API/system-prompt disclosure; no bot/owner gender.
- User-facing errors never include raw provider failures (e.g. Gemini 429). Soft Neko-style declines only; full detail in structured logs.
- Identity probe questions ("are you Gemini?", "what model?") answered in character without hitting provider leak paths.
- Owner-only diagnostics: `/aihealth`, `/ai_status`, `/aistatus`, `/fallbackinfo`.
- Optional free OpenAI-compatible provider via `FREE_AI_API_KEY` + `FREE_AI_BASE_URL` (+ `FREE_AI_MODEL`).

### Anime (`bot/plugins/anime.py`)
- AniList remains primary.
- MyAnimeList via Jikan v4 (no API key) as fallback and for dual links.
- `/anime`, `/manga`, `/character` show AniList + MAL buttons when IDs exist.
- `/seasonal` now lists currently airing titles from MAL/Jikan.

### Config
- New optional env: `FREE_AI_API_KEY`, `FREE_AI_BASE_URL`, `FREE_AI_MODEL`.

---

## Safe hardening pass (2026-09-23)

Non-regressive improvements only — no feature removal, no behavior change for successful paths.

### Error hygiene (`bot/core/errors.py`)
- Added `user_facing_error()` helper for plugins (log full exception, return safe string).
- Leak marker filter blocks provider names, quota text, tracebacks, API key hints in user replies.
- `reply_safe` applies the same filter as a last line of defense.
- `NekoError.user_message` still preferred when it does not look internal.

### Ambient handler isolation
`@safe_handler` on previously bare ambient listeners so exceptions cannot spam the global “sideways” reply:
- `economy.xp_listener`
- `fonts.handle_message` (auto-style)
- `group_mgmt.filter_listener`, `lock_listener`
- `collector.spawn_listener`
- `fun.afk_listener`

Successful early-returns are unchanged.

### Admin
- `/slowmode` no longer replies with raw `str(e)`.

### UX copy (`start` / `help`)
- Clear `/ai` (assistant) vs `/chat` + mention/reply (personality).
- Anime line notes AniList + MyAnimeList; `/seasonal` listed.

### Startup self-check (`bot/core/bot.py`)
- `_verify_data_assets()` logs missing critical files under `DATA_DIR` (neko skin, few-shot bank, jokes) without aborting boot.

### AI routing (`bot/plugins/ai.py`)
- Internal provider cooldown after 3 consecutive failures (60s skip).
- Success resets streak. Never mentioned to users.

---

## Menu + live music fix (2026-09-23)

### Root causes

**`/menu` appeared broken** because it was a cosmetic shell: every button opened a generic "Feature panel for X — use /X" stub. Many labels (Cricket, Cosplay, Pokedex, OCR, Upscale, …) had **no implementation** in this codebase at all. Users correctly experienced "nothing works."

**Live VC music** failed on every `/play` in typical installs because `audio_engine.play()` called:

```python
join_group_call(chat_id, stream, stream_type=StreamAudioEnded())
```

`StreamAudioEnded` is an **event** type (stream finished), not a stream mode. That argument is invalid across py-tgcalls versions and caused join to fail while the UI only said "Couldn't join the voice chat."

### Fixes

1. **Functional menu (`bot/plugins/start.py`)**
   - Rebuilt around commands that actually exist in this bot.
   - 3 pages of categories; each button opens a real command guide.
   - Removed fake categories that mapped to nothing.
   - `/help` and `/settings` aligned (AI vs personality, live music status).

2. **Live music engine (`bot/services/audio_engine.py`)**
   - Removed invalid `stream_type=StreamAudioEnded()`.
   - Compatibility path: try `play()` → `join_group_call(chat, stream)` → legacy `StreamType.pulse_stream` if needed.
   - Prefer `leave_call` when present; fall back to `leave_group_call`.
   - Support `MediaStream` when `AudioPiped` is unavailable.
   - If already in the call, use `change_stream` before re-joining.
   - Clearer user-facing failure checklist (VC open, bot admin, API credentials, ffmpeg).

3. **`/play` hardening (`music_live.py`)**
   - `@safe_handler` on `play_cmd`.
   - Safer yt-dlp options (android/web player clients).
   - Resolve failures no longer dump raw exception text to chat.

### Ops checklist for live music (still required by Telegram)

1. `MUSIC_API_ID` + `MUSIC_API_HASH` from my.telegram.org in `.env`
2. Active **voice chat** already open in the group
3. Bot is a **member** of the group (admin recommended)
4. `ffmpeg` installed on the host
5. Restart bot after env change; check logs for `music_client_ready` / `playback_error`

### Not a regression

- All previously working slash commands unchanged.
- File download `/music` still independent of live VC.
- Menu only documents real commands; does not remove any handlers.

---

## Safe hardening batch 2 (2026-09-23)

Additive-only changes; successful user paths unchanged.

### Observability
- Structlog secret redaction (`api_key`, `token`, `Bearer`, etc.) in `setup_logging`.
- Log middleware attaches `update_id` for correlating errors.

### Performance
- Antiflood / antispam: 45s TTL admin-status cache (fewer `get_chat_member` calls).
- Anime: 15-minute TTL cache (max 256) for AniList + Jikan responses.

### Live music
- Re-extract playable stream URL at **play time** from `source_url` (mitigates CDN expiry).
- Owner `/musichealth` (`/music_status`, `/musicstatus`): configured?, pool, ffmpeg, active chats.

### AI
- `/aiclear` (`/ai_clear`, `/clearai`): clears that user’s `/ai` history only.

### Honesty
- `/tts`: no longer pretends gTTS is integrated; clear “not available on this build”.
- `docs/FEATURE_MATRIX.md`: command → status map; lists non-implemented ghosts explicitly.

### Files
- `bot/utils/logger.py`, `bot/core/bot.py`
- `bot/middleware/logging_middleware.py`, `antiflood.py`, `antispam.py`
- `bot/plugins/anime.py`, `music_live.py`, `ai.py`, `music.py`, `start.py`
- `bot/services/audio_engine.py`
- `docs/FEATURE_MATRIX.md`, `ENGINEERING_SUMMARY.md`

---

## Personality catalog expansion + superowner management (2026-09-23)

### Catalog
- Expanded skins + matching presets to **109** each (from ~25).
- Coverage: anime-style *dere archetypes, classic literary tones, RPG roles,
  modern professions, emotional modes, genre voices (noir, gothic, zen, …).
- Generic tropes only — no copyrighted character names as skin IDs.
- Note: "every personality in the universe" is infinite; this is a broad,
  practical archetypal set. Superowner can add unlimited more via Telegram.

### Superowner (OWNER_ID) Telegram commands
| Command | Purpose |
|---------|---------|
| `/plist` | List all skins + presets |
| `/pshow skin\|preset <name>` | Inspect JSON |
| `/preload` | Reload from disk |
| `/padd skin\|preset <name> [desc]` | Create |
| `/pdel skin\|preset <name>` | Delete (neko/nanora protected) |
| `/pmerge skin\|preset <src> <tgt>` | Merge data into target |
| `/pset skin\|preset <name> <field> <value>` | Set field |
| `/pdata <skin> <category> <line>` | Append response line(s); reply for bulk |
| `/pmeta <skin> <category> <text>` | Append metaphor |
| `/pjson skin\|preset <name>` | Replace from replied JSON |
| `/padmin` / `/personaadmin` | Help |

### APIs
- `SkinLoader.save/delete/merge/get_raw/exists`
- `PresetLoader.save/delete/merge/get_raw`
- `CustomInstructionProcessor.save_preset/delete_preset/merge_presets`


---

## Contract tests + analysis lock-in (2026-09-23)

Added `tests/test_hardening_contracts.py` (no Telegram runtime required):
- Catalog: ≥100 skins/presets parse as JSON; neko/nanora present; few-shot ≥300
- Error module still defines leak markers + user_facing_error
- Every /menu label has a MENU_PANELS key
- Superowner persona commands are registered
- Audio engine must not pass StreamAudioEnded as stream_type; play-time URL refresh present

All 6 tests passing.

---

## Safe handler coverage + persistence backup (2026-09-23)

- Applied `@safe_handler` to remaining plugin *handlers* that still raised into the global error path (automod, collector commands, economy commands, federations, fun, group_mgmt, music_live extras, scheduling, etc.).
- Did **not** wrap internal helpers that return ints/bools (`_target_chat_id`, `_is_admin`, `_require_gate`) so call-sites keep typed returns.
- Successful handler returns are unchanged; only uncaught exceptions are logged + soft-replied.
- `bot_data.pkl` is copied to `bot_data.pkl.bak` on startup when present (best-effort) to survive a later corrupt pickle write.
- `requirements.txt` notes to freeze pyrogram/py-tgcalls together in production.
- Contract tests still pass (6/6). All `bot/**/*.py` parse.
