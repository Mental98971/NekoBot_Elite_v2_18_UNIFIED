# Engineering Summary — Neko Bot Fix (2026-09-22)

## Symptom
Every message the bot received triggered the global error reply:

> Something went sideways inside Neko. The error is logged.

This is the user-facing text from `bot/core/bot.py` → `global_error_handler` when any unhandled exception escapes a handler.

## Root Cause
The personality layer (enabled by default in DMs) runs on nearly every non-command text message. Two data loaders used **cwd-relative** paths:

| Component | Old path | Problem |
|-----------|----------|---------|
| `SkinLoader` (`bot/personality/personality.py`) | `"data/personality/skins"` | Only works if process CWD is project root |
| Few-shot bank (`bot/personality/examples.py`) | `"data/personality/dataset/fewshot_bank.json"` | Same |

When the bot is started under systemd, Docker with a different `WORKDIR`, or `python -m` from another directory, those files are not found. `SkinLoader.load()` fell back to `neko.json`, then did an unguarded `path.read_text()`, raising `FileNotFoundError`. That exception was **not** caught in `handle_message` / `generate_direct` / `rewrite`, so it bubbled to the global handler and produced the message on every send.

Other loaders (jokes, custom-instruction presets) already used `settings.data_dir` and were unaffected.

## Changes (no feature loss, no regressions)

### 1. Path resolution (correctness)
- `SkinLoader` now resolves against `settings.data_dir / "personality" / "skins"`.
- Few-shot bank uses `settings.data_dir / "personality" / "dataset" / "fewshot_bank.json"`.
- Aligns with jokes, presets, and the rest of the project.

### 2. Defensive skin load (availability)
- If even the fallback `neko.json` is missing, `SkinLoader` returns a minimal safe skin instead of crashing.
- Logging is explicit so operators can see a misconfigured data directory.

### 3. Personality message handler (isolation)
- Generation / rewrite / subplugin routing is wrapped in try/except inside `handle_message`.
- A future personality bug can no longer spam the global “sideways” reply; it is logged and the update is skipped for that path only.

### 4. ChatMemberStatus consistency (compatibility)
- Two remaining uses of the pre-v20 name `ChatMemberStatus.CREATOR` were updated to `ChatMemberStatus.OWNER` (python-telegram-bot ≥ 20).
  - `bot/plugins/personality.py` (`_is_admin`)
  - `bot/plugins/music_live.py` (music control permission check)
- No behavior change: both constants map to the same Telegram status `'creator'`.

## What was **not** changed
- All plugins, middleware, models, database schema, commands, economy, music, collector, federations, automod, fonts, reactions, dashboard, tests, Docker, CI, and data assets (skins, presets, few-shot bank, jokes) are intact.
- No public API, command set, or config surface was altered.
- No dependency versions were bumped.
- Default personality behavior (DM on / group off, skins, cooldowns, limits) is unchanged when data files are present.

## Deploy notes
1. Unpack over an existing install or use this tree as the new source of truth.
2. Ensure `DATA_DIR` (default `./data`) contains `personality/skins/neko.json` (and the rest of the skins/presets/dataset shipped in this archive).
3. Restart the process (or rebuild the image). No migration step required.
4. If the error persists, inspect structured logs for `unhandled_update_error` or `personality_generate_failed` — the user-facing text deliberately hides internals.

## Files touched
- `bot/personality/personality.py` — SkinLoader path + safe fallback
- `bot/personality/examples.py` — few-shot path
- `bot/plugins/personality.py` — try/except around generate + CREATOR→OWNER
- `bot/plugins/music_live.py` — CREATOR→OWNER

## Verification checklist
- [ ] Bot starts without import errors
- [ ] DM text message gets a personality reply (or silence if cooldown/limit), **not** the sideways message
- [ ] Group messages with personality off behave as before
- [ ] `/play`, admin checks, fonts, economy XP still work
- [ ] Logs show no `FileNotFoundError` for skins when CWD ≠ project root

---

## Identity protection & anime dual-source (2026-09-23)

### AI identity rules (`bot/plugins/ai.py`)
- System prompt always includes an identity guard: no provider/model/API/system-prompt disclosure; no bot/owner gender.
- User-facing errors never include raw provider failures (e.g. Gemini 429). Soft Neko-style declines only; full detail in structured logs.
- Identity probe questions ("are you Gemini?", "what model?") answered in character without hitting provider leak paths.
- Owner-only diagnostics: `/aihealth`, `/ai_status`, `/aistatus`, `/fallbackinfo`.
- Optional free OpenAI-compatible provider via `FREE_AI_API_KEY` + `FREE_AI_BASE_URL` (+ `FREE_AI_MODEL`).

### Anime (`bot/plugins/anime.py`)
- AniList remains primary.
- MyAnimeList via Jikan v4 (no API key) as fallback and for dual links.
- `/anime`, `/manga`, `/character` show AniList + MAL buttons when IDs exist.
- `/seasonal` now lists currently airing titles from MAL/Jikan.

### Config
- New optional env: `FREE_AI_API_KEY`, `FREE_AI_BASE_URL`, `FREE_AI_MODEL`.

---

## Safe hardening pass (2026-09-23)

Non-regressive improvements only — no feature removal, no behavior change for successful paths.

### Error hygiene (`bot/core/errors.py`)
- Added `user_facing_error()` helper for plugins (log full exception, return safe string).
- Leak marker filter blocks provider names, quota text, tracebacks, API key hints in user replies.
- `reply_safe` applies the same filter as a last line of defense.
- `NekoError.user_message` still preferred when it does not look internal.

### Ambient handler isolation
`@safe_handler` on previously bare ambient listeners so exceptions cannot spam the global “sideways” reply:
- `economy.xp_listener`
- `fonts.handle_message` (auto-style)
- `group_mgmt.filter_listener`, `lock_listener`
- `collector.spawn_listener`
- `fun.afk_listener`

Successful early-returns are unchanged.

### Admin
- `/slowmode` no longer replies with raw `str(e)`.

### UX copy (`start` / `help`)
- Clear `/ai` (assistant) vs `/chat` + mention/reply (personality).
- Anime line notes AniList + MyAnimeList; `/seasonal` listed.

### Startup self-check (`bot/core/bot.py`)
- `_verify_data_assets()` logs missing critical files under `DATA_DIR` (neko skin, few-shot bank, jokes) without aborting boot.

### AI routing (`bot/plugins/ai.py`)
- Internal provider cooldown after 3 consecutive failures (60s skip).
- Success resets streak. Never mentioned to users.

---

## Menu + live music fix (2026-09-23)

### Root causes

**`/menu` appeared broken** because it was a cosmetic shell: every button opened a generic "Feature panel for X — use /X" stub. Many labels (Cricket, Cosplay, Pokedex, OCR, Upscale, …) had **no implementation** in this codebase at all. Users correctly experienced "nothing works."

**Live VC music** failed on every `/play` in typical installs because `audio_engine.play()` called:

```python
join_group_call(chat_id, stream, stream_type=StreamAudioEnded())
```

`StreamAudioEnded` is an **event** type (stream finished), not a stream mode. That argument is invalid across py-tgcalls versions and caused join to fail while the UI only said "Couldn't join the voice chat."

### Fixes

1. **Functional menu (`bot/plugins/start.py`)**
   - Rebuilt around commands that actually exist in this bot.
   - 3 pages of categories; each button opens a real command guide.
   - Removed fake categories that mapped to nothing.
   - `/help` and `/settings` aligned (AI vs personality, live music status).

2. **Live music engine (`bot/services/audio_engine.py`)**
   - Removed invalid `stream_type=StreamAudioEnded()`.
   - Compatibility path: try `play()` → `join_group_call(chat, stream)` → legacy `StreamType.pulse_stream` if needed.
   - Prefer `leave_call` when present; fall back to `leave_group_call`.
   - Support `MediaStream` when `AudioPiped` is unavailable.
   - If already in the call, use `change_stream` before re-joining.
   - Clearer user-facing failure checklist (VC open, bot admin, API credentials, ffmpeg).

3. **`/play` hardening (`music_live.py`)**
   - `@safe_handler` on `play_cmd`.
   - Safer yt-dlp options (android/web player clients).
   - Resolve failures no longer dump raw exception text to chat.

### Ops checklist for live music (still required by Telegram)

1. `MUSIC_API_ID` + `MUSIC_API_HASH` from my.telegram.org in `.env`
2. Active **voice chat** already open in the group
3. Bot is a **member** of the group (admin recommended)
4. `ffmpeg` installed on the host
5. Restart bot after env change; check logs for `music_client_ready` / `playback_error`

### Not a regression

- All previously working slash commands unchanged.
- File download `/music` still independent of live VC.
- Menu only documents real commands; does not remove any handlers.

---

## Safe hardening batch 2 (2026-09-23)

Additive-only changes; successful user paths unchanged.

### Observability
- Structlog secret redaction (`api_key`, `token`, `Bearer`, etc.) in `setup_logging`.
- Log middleware attaches `update_id` for correlating errors.

### Performance
- Antiflood / antispam: 45s TTL admin-status cache (fewer `get_chat_member` calls).
- Anime: 15-minute TTL cache (max 256) for AniList + Jikan responses.

### Live music
- Re-extract playable stream URL at **play time** from `source_url` (mitigates CDN expiry).
- Owner `/musichealth` (`/music_status`, `/musicstatus`): configured?, pool, ffmpeg, active chats.

### AI
- `/aiclear` (`/ai_clear`, `/clearai`): clears that user’s `/ai` history only.

### Honesty
- `/tts`: no longer pretends gTTS is integrated; clear “not available on this build”.
- `docs/FEATURE_MATRIX.md`: command → status map; lists non-implemented ghosts explicitly.

### Files
- `bot/utils/logger.py`, `bot/core/bot.py`
- `bot/middleware/logging_middleware.py`, `antiflood.py`, `antispam.py`
- `bot/plugins/anime.py`, `music_live.py`, `ai.py`, `music.py`, `start.py`
- `bot/services/audio_engine.py`
- `docs/FEATURE_MATRIX.md`, `ENGINEERING_SUMMARY.md`

---

## Personality catalog expansion + superowner management (2026-09-23)

### Catalog
- Expanded skins + matching presets to **109** each (from ~25).
- Coverage: anime-style *dere archetypes, classic literary tones, RPG roles,
  modern professions, emotional modes, genre voices (noir, gothic, zen, …).
- Generic tropes only — no copyrighted character names as skin IDs.
- Note: "every personality in the universe" is infinite; this is a broad,
  practical archetypal set. Superowner can add unlimited more via Telegram.

### Superowner (OWNER_ID) Telegram commands
| Command | Purpose |
|---------|---------|
| `/plist` | List all skins + presets |
| `/pshow skin\|preset <name>` | Inspect JSON |
| `/preload` | Reload from disk |
| `/padd skin\|preset <name> [desc]` | Create |
| `/pdel skin\|preset <name>` | Delete (neko/nanora protected) |
| `/pmerge skin\|preset <src> <tgt>` | Merge data into target |
| `/pset skin\|preset <name> <field> <value>` | Set field |
| `/pdata <skin> <category> <line>` | Append response line(s); reply for bulk |
| `/pmeta <skin> <category> <text>` | Append metaphor |
| `/pjson skin\|preset <name>` | Replace from replied JSON |
| `/padmin` / `/personaadmin` | Help |

### APIs
- `SkinLoader.save/delete/merge/get_raw/exists`
- `PresetLoader.save/delete/merge/get_raw`
- `CustomInstructionProcessor.save_preset/delete_preset/merge_presets`


---

## Contract tests + analysis lock-in (2026-09-23)

Added `tests/test_hardening_contracts.py` (no Telegram runtime required):
- Catalog: ≥100 skins/presets parse as JSON; neko/nanora present; few-shot ≥300
- Error module still defines leak markers + user_facing_error
- Every /menu label has a MENU_PANELS key
- Superowner persona commands are registered
- Audio engine must not pass StreamAudioEnded as stream_type; play-time URL refresh present

All 6 tests passing.

---

## Independent verification pass (2026-09-23)

This round re-uploaded all 11 archives from prior rounds — the ones
named MAXIMUM / ULTIMATE / ULTIMATE-PACKED / v5-MAXIMUM-LAYERS /
v5-enhanced / v6-COMPLETE / consolidated / fixed / neko_v2_4 /
novabot-with-nanora-v3 / novabot-neko-v4 — into a fresh session with
no memory of the work above, plus a general-purpose "merge everything
into one production system" instruction. Re-derived the same lineage
independently from file-hash overlap across all 11 archives *before*
reading this file or the README; the independent result matched what
was already written here and below.

**Checked (real, in this sandbox):**
- All 82 `.py` files in this tree byte-compile with no syntax errors.
- All 285 internal `bot.*` import statements resolve to a real file
  in the tree (static check — the third-party dependencies below
  aren't installable here, so this is the offline equivalent of an
  import check).
- No hardcoded secrets: scanned for Telegram-bot-token, OpenAI-style,
  and AWS-style key patterns, plus generic `token=`/`secret=`/
  `password=` assignments, across the whole tree — none found.
  `.env.example` is placeholders only; `.gitignore` excludes `.env`,
  `sessions/`, `*.db`; `sessions/` itself is empty.
- Spot-checked specific fixes this file describes against the actual
  source (not just the prose): `economy_service.try_spend`'s atomic
  SQL `UPDATE`, `global_error_handler` / `_verify_data_assets` in
  `core/bot.py`, the leak filter in `core/errors.py`, and the
  `StreamAudioEnded` guard + comment in `audio_engine.py` are all
  genuinely present and match what's described above.
- Personality catalog: 109 skin files / 109 preset files on disk,
  matching the count claimed above. The pre-rebrand "Saria Nakano..."
  line does not appear anywhere in the actual dataset — only in this
  changelog and `docs/FEATURE_INVENTORY.md`, as history. Sampled
  skins (`neko`, `pirate`, `tsundere`) are generic archetypes with no
  copyrighted names, consistent with this file's "no copyrighted
  character names as skin IDs" note.
- Reviewed `docker-compose.yml`, both `Dockerfile`s, `dashboard/main.py`,
  and `.github/workflows/ci.yml` — consistent with each other and with
  the README (CI installs `requirements*.txt`, byte-compiles, lints
  with ruff, then runs `pytest tests/`).

**Not executable here:** this sandbox has no network access, so
`python-telegram-bot`, `pyrogram`, `sqlalchemy`, and the rest of
`requirements.txt` can't be installed, and neither the live bot nor
`pytest tests/` can actually be run. `.github/workflows/ci.yml`
already does exactly this on every push/PR — the byte-compile and
static-import results above are the closest equivalent achievable
offline. Treat this pass as "no defects found by static inspection,"
not as "tests pass."

**Not re-litigated:** the `datetime.utcnow()` count, `cache.py` /
`validation.py` integration depth, and the sampled `except: pass`
sites — all previously reviewed and deliberately deferred above with
stated reasoning that still holds. No new evidence surfaced this round
to revisit those calls, so they were left alone rather than "fixed"
without cause.

No source file was modified. The only change made was removing build
artifacts (`__pycache__/`, `*.pyc`) that this session's own compile
checks had created, before repackaging.

---

## Branch reconciliation — this branch merged with `neko-bot-consolidated`'s lineage (2026-09-25)

The prior "Independent verification pass" above treated this branch's
own history as authoritative and re-derived it from 11 archives that
included a `consolidated`/`fixed` snapshot — but that snapshot turned
out to be an **older** point on a lineage that, unknown to that round,
had kept moving forward independently. This round's uploads included
the actual current `neko-bot-consolidated.zip` (104 tests passing,
verified against this project's own memory of that lineage's history),
which carried real fixes this branch never had: `/chat` no longer
aliased to `/ai`, a direct-@mention/reply bypass for the ambient
personality toggle, force-subscribe defaulting off (this branch still
defaulted it on), and a dedicated end-to-end test driving the real
message-handler + middleware chain.

Concretely (not by assumption): grepped both branches for each other's
signature fixes before touching anything. `consolidated` had every fix
in this file's history *except* the cwd-relative personality-path bug,
the `StreamAudioEnded` pytgcalls bug, the 109-skin/109-preset catalog,
AI identity-leak protection, the dual anime source, the menu rebuild,
and the superowner persona-admin commands. This branch had none of
`consolidated`'s later fixes. Used `consolidated` as the base (it had
the more recent, better-tested routing/security fixes) and ported this
branch's independent value onto it — reimplementing each targeted
change rather than diffing the two histories together, per this
project's own established practice for reconciling divergent branches.

**Network access was available this round** (unlike the prior "not
executable here" pass): built a real Python 3.12 virtualenv, installed
every dependency in `requirements-dev.txt`, and actually ran the test
suite — this round's numbers are real `pytest` output, not static
inspection. Baseline on the unmodified `consolidated` branch: 104
passed. After porting this branch's fixes on top and re-running after
every change: 114 passed (104 original + 10 new hardening-contract
tests), zero regressions, zero skipped.

**A real, previously-unknown bug was caught by this process**: merging
this branch's 109-skin/109-preset catalog onto `consolidated` broke two
existing keyword-matching tests. Root cause was in the catalog data
itself, not the merge logic — 84 of the 109 presets had keyword lists
built by naively splitting a description sentence on whitespace, so
lists like `["artisan", "artisan", "craft-focused;", "process", "and",
"quality."]` included the bare stopword `"and"`, which matches almost
any multi-clause user message and can out-score a genuinely relevant
preset on tie-broken keyword-count matching. Fixed by cleaning all 109
preset keyword lists (strip stray punctuation, drop stopwords, dedupe)
rather than patching the two presets that happened to trip a test —
scanned the whole catalog for the same defect class first. Added
`test_no_stopword_only_preset_keywords` as a permanent regression guard.

**Also fixed while merging, found via the same "check concretely, don't
assume" pass**: the pre-v20 `ChatMemberStatus.CREATOR` name was still
used in two places on the `consolidated` branch (this branch had
already updated both to `OWNER`); `/menu` on the `consolidated` branch
had the same class of bug this branch's own history describes above —
~60 buttons for features that don't exist in this bot, all opening an
identical "Feature panel for `<module>`" placeholder — rebuilt as 17
real categories with real command lists, verified against the actual
plugin set rather than copied from this branch's own (smaller) command
surface; and this branch's own `/aihealth` owner diagnostic had been
missed on the first merge pass and was added in a follow-up pass once
the gap was noticed.

**Repackaged at the repo root** (no `novabot/` wrapper directory) to
match this branch's own layout convention, since it doesn't require an
extra `cd` after cloning.

**Not re-litigated**, same as the prior round: the `datetime.utcnow()`
count, `cache.py`/`validation.py` integration depth, and the sampled
`except: pass` sites. No new evidence surfaced to revisit those calls.

## Round: NekoBot_Production reconciled, 13 re-uploaded archives re-verified (2026-09-26)

13 archives arrived this round, several sharing exact filenames with archives from earlier rounds. Each was extracted and checked against concrete signatures (force-sub default, catalog size, `OWNER` vs. `CREATOR` usage, `/chat` registration location, presence of `_is_direct_address`) rather than assumed current from its filename alone. 11 of the 13 needed no action: `neko-bot-fixed`/`novabot-neko-final` were confirmed via `diff -rq` to contain zero files not already in this repo; `Character_Collector_Plugin.zip` was line-for-line identical to this repo's own `collector.py`; the remaining 8 matched signatures of branches already mined in earlier rounds.

`NekoBot_Production.zip` was new: a third lineage sharing a common ancestor with this repo as of the "Safe hardening pass" above, evolved independently afterward. Full diff (not signature matching) against every shared file found real value — a working `couples_cmd` (this repo's own version was a placeholder promising a `/trackusers` command that doesn't exist anywhere), broader `@safe_handler` coverage, a `bot_data.pkl` startup backup, a yt-dlp hardening pass, leak-safe error messages via the existing `user_facing_error()` helper in two more plugins, a py-tgcalls `leave_call`/`leave_group_call` compatibility shim, `/tban`/`/tmute` aliases, bot-@mention stripping before the personality pipeline, and a new `utilities.py` plugin (`/id /info /tr /weather /imdb /calc /tagall /dice /fun /warns /resetwarns /stats`) — every command in its own hub text confirmed to already exist elsewhere before shipping, the same discipline as the `/menu` rebuild above. The same diff also showed this branch was simply behind this repo in `config.py` (force-sub on by default against a placeholder channel), `health.py`, and `examples.py` (both still cwd-relative) — left untouched rather than treated as a merge target. A `configure_secret_redaction()` whose body was `pass` was found and not ported.

Full command-collision audit against the complete merged system: 304 unique commands, zero collisions; 23/23 plugins import and register; 274 handlers. New tests: `tests/test_fun.py`, `tests/test_utilities.py` (the calculator specifically tested against function-call/name-lookup/attribute-access/string-literal injection attempts, not just malformed syntax). 134 passed, 0 failed (was 114 at the start of this round), verified from a fresh extraction of the packaged zip, not just the working copy.

**Not re-litigated**: same deferred items as the prior round — `datetime.utcnow()` usage, `cache.py`/`validation.py` integration depth, sampled `except: pass` sites. No new evidence surfaced to revisit those calls this round either.
