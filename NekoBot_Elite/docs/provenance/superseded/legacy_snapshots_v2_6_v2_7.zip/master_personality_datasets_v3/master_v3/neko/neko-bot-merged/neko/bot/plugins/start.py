"""
Start handler, help, and the inline menu system — rebuilt around commands
that actually exist in this bot. Each category button shows the real
command list for that category instead of a generic placeholder panel.
"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
from bot.identity import bot_name
from bot.utils.helpers import mention_html
from bot.core.errors import safe_handler


# name -> (emoji label, detail text shown when the button is tapped)
CATEGORIES = {
    "mod": ("👮 Moderation", "/ban /mute /kick /warn /purge /tmute /tban"),
    "security": ("🛡️ Security", "/antispam /antiflood /captcha /locks /nightmode"),
    "manage": ("📝 Chat management", "/notes /filters /welcome /rules /setwelcome /setrules"),
    "ai": ("🤖 AI", "/ai /chat /imagine /summarize /code /persona /see /transcribe /aiclear"),
    "anime": ("🎌 Anime", "/anime /manga /character /seasonal"),
    "music": ("🎧 Live music", "/play /skip /pause /resume /stop /queue /nowplaying /volume /shuffle /loop /lyrics"),
    "fun": ("🎯 Fun", "/fun /couples /meme /quote /wish /trivia /tictactoe /poll"),
    "collector": ("🎴 Collector", "/grab /collection /characters /fav /trade /gift /smelt /cstats /giveaway — see /chelp"),
    "economy": ("💰 Economy", "/daily /balance /shop /level /leaderboard /pay"),
    "utils": ("🔧 Utilities", "/id /info /tr /ud /qr /calc /imdb /weather"),
    "stats": ("📊 Stats", "/stats /mystats /botstats /top /leaderboard"),
    "fed": ("🌐 Federations", "/newfed /joinfed /leavefed /fedban /unfedban /fedinfo /fpromote /fedadmins"),
    "admin": ("🛠 Admin ops", "/disable /enable /disabled /zombies /rmzombies /unbanall /names"),
    "sudo": ("🛡 Owner ops", "/globalstats /activevc /blacklistchat /authorize /maintenance /privatemode /gban"),
    "persona": ("🎭 Personality", "/personality on|off, /chat, /joke — sarcastic banter, on by default in DMs. "
                                   "A direct @mention or reply always gets a reply."),
    "fonts": ("🔤 Fonts", "/f1–/f18, /flip, /fontfx, /random, /mix, /reverse, /fonts"),
    "reactions": ("🤗 Reactions", "/reactions on|off, then /hug /pat /kiss /cuddle /slap /poke /tickle /bonk + 22 more"),
}

# 3 pages of 6 buttons each, in the order above.
_KEYS = list(CATEGORIES.keys())
_PAGES = [_KEYS[i:i + 6] for i in range(0, len(_KEYS), 6)]


def _build_keyboard(page_num: int):
    page_keys = _PAGES[page_num - 1]
    buttons = []
    row = []
    for key in page_keys:
        label = CATEGORIES[key][0]
        row.append(InlineKeyboardButton(label, callback_data=f"menu:{key}"))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)

    nav = []
    total = len(_PAGES)
    if page_num > 1:
        nav.append(InlineKeyboardButton("⬅️", callback_data=f"page:{page_num - 1}"))
    nav.append(InlineKeyboardButton("🗑", callback_data="close"))
    if page_num < total:
        nav.append(InlineKeyboardButton("➡️", callback_data=f"page:{page_num + 1}"))
    buttons.append(nav)
    return InlineKeyboardMarkup(buttons)


@safe_handler
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = (
        f"<b>👋 Welcome, {mention_html(user.id, user.first_name)}!</b>\n\n"
        f"<i>🚀 {bot_name()}</i> — moderation, AI chat, live voice-chat music, "
        f"a sarcastic personality mode, an anime character collector, and Unicode "
        f"font styling, all in one bot.\n"
        f"Tap a category below, or send /help for the full command list."
    )
    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=_build_keyboard(1),
    )


@safe_handler
async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    total = len(_PAGES)

    if data.startswith("page:"):
        page = max(1, min(total, int(data.split(":")[1])))
        await query.edit_message_text(
            f"<b>📋 {bot_name()} Control Panel</b> — Page {page}/{total}\nTap a category:",
            parse_mode="HTML",
            reply_markup=_build_keyboard(page),
        )
    elif data == "close":
        await query.delete_message()
    else:
        key = data.split(":", 1)[1]
        category = CATEGORIES.get(key)
        if not category:
            await query.answer("Unknown category.", show_alert=True)
            return
        label, commands = category
        await query.edit_message_text(
            f"<b>{label}</b>\n\n{commands}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="page:1")]
            ]),
        )


@safe_handler
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "<b>📚 " + bot_name() + " Help</b>\n\n"
        "<b>👮 Moderation:</b> /ban /mute /kick /warn /purge /tmute /tban\n"
        "<b>🛡️ Security:</b> /antispam /antiflood /captcha /locks /nightmode\n"
        "<b>📝 Management:</b> /notes /filters /welcome /rules /setwelcome /setrules\n"
        "<b>🤖 AI:</b> /ai /imagine /summarize — general AI chat, uses /persona\n"
        "<b>🎌 Anime:</b> /anime /manga /character /schedule /news\n"
        "<b>🎵 Media:</b> /music /yt /insta /tiktok /tts\n"
        "<b>🎯 Fun:</b> /fun /couples /meme /quote /wish\n"
        "<b>🎴 Collector:</b> /grab (catch a spawned character), /collection /characters "
        "/fav /myprofile /topcatchers /trade /gift — see /chelp for the full list\n"
        "<b>🔧 Utilities:</b> /id /info /tr /ud /weather /qr /calc /imdb\n"
        "<b>📊 Stats:</b> /stats /mystats /botstats /top /leaderboard\n"
        "<b>🌐 Fed:</b> /newfed /joinfed /leavefed /fedban /unfedban /fedinfo /fpromote /fedadmins\n"
        "<b>🛠 More admin:</b> /disable /enable /disabled, /zombies /rmzombies (deleted accounts), /unbanall, /names (name history)\n"
        "<b>🎧 Live Music:</b> /play (YT/Spotify/Apple/SoundCloud/Resso links or search) "
        "/skip /pause /resume /stop /queue /nowplaying /volume /shuffle /repeat /effects "
        "/loop /seek /seekback /playlist /lyrics /channelplay /videomode /toptracks "
        "/resetqueue <i>(voice chat)</i>\n"
        "<b>🛡 Ops (sudo):</b> /globalstats /activevc /blacklistchat /authorize "
        "/maintenance /privatemode /cleanmode /autoend /speedtest /gban /block\n"
        "<b>🎭 Personality:</b> /personality on|off, /chat &lt;msg&gt;, /joke — sarcastic "
        "banter mode (on by default in DMs). A direct @mention or a reply to one of "
        "my messages always gets a personality reply, even where ambient banter is off\n"
        "<b>🔤 Fonts:</b> /f1–/f18, /flip, /fontfx (+shortcuts: /stinky /bubbles "
        "/underline /rays /strike /frozen...), /random, /mix, /reverse, /fonts\n\n"
        "<b>🤗 Reactions:</b> /reactions on|off, then /hug /pat /kiss /cuddle /slap "
        "/poke /tickle /bonk and 22 more anime-style GIF reactions — target someone "
        "by replying or @mentioning them\n\n"
        "<i>Tap /menu for the inline control panel, or /settings for quick toggles.</i>"
    )
    await update.message.reply_text(text, parse_mode="HTML")


@safe_handler
async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Quick-glance settings panel: personality mode for this chat, plus
    pointers to the other per-feature settings commands."""
    from bot.config import settings as cfg
    from bot.core.database import async_session, Chat

    chat = update.effective_chat
    personality_state = "default"
    if chat.type != "private":
        async with async_session() as session:
            row = await session.get(Chat, chat.id)
            if row and row.personality_enabled is not None:
                personality_state = "on" if row.personality_enabled else "off"
    else:
        personality_state = "on (default in DMs)" if cfg.personality_default_dm else "off"

    text = (
        "<b>⚙️ " + bot_name() + " Settings</b>\n\n"
        f"<b>🎭 Personality mode:</b> <code>{personality_state}</code>\n"
        f"Toggle with /personality on or /personality off (group admins only).\n\n"
        "<b>🔤 Font preferences:</b> see /fontsettings\n"
        "<b>🎧 Music volume:</b> see /volume\n"
        "<b>🛡️ Moderation options:</b> /locks, /filters, /captcha, /nightmode\n"
    )
    await update.message.reply_text(text, parse_mode="HTML")


def register(app):
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("menu", start_command))
    app.add_handler(CommandHandler("settings", settings_command))
    app.add_handler(CallbackQueryHandler(menu_callback, pattern=r"^(page:|menu:|close)"))
