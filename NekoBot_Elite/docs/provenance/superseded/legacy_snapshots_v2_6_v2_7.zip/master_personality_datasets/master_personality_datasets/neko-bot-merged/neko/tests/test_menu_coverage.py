"""
Tests for the expanded /menu in bot/plugins/start.py.

This round folded many real, already-working commands into /menu that
weren't represented in any category before (games.py wasn't mentioned
at all; tts/qr/ud/insta/yt/purge/report existed as working commands
but weren't in the menu). This suite locks in:
- every category button actually renders a real panel (no KeyError/
  crash for any key in CATEGORIES)
- pagination math is correct for the current category count
- the categories collectively don't regress back to missing whole
  plugins worth of real commands
"""
from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

os.environ.setdefault("BOT_TOKEN", "123:test")
os.environ.setdefault("OWNER_ID", "123456")
os.environ.setdefault("DATABASE_URL", f"sqlite+aiosqlite:///{tempfile.mktemp(suffix='.db')}")

import bot.plugins.start as start_plugin  # noqa: E402


def _make_callback_update(data: str):
    update = MagicMock()
    update.callback_query.data = data
    update.callback_query.answer = AsyncMock()
    update.callback_query.edit_message_text = AsyncMock()
    update.callback_query.delete_message = AsyncMock()
    context = MagicMock()
    return update, context


class TestEveryCategoryRendersARealPanel(unittest.IsolatedAsyncioTestCase):
    async def test_every_category_key_opens_without_error(self):
        for key in start_plugin.CATEGORIES:
            update, context = _make_callback_update(f"menu:{key}")
            await start_plugin.menu_callback(update, context)
            update.callback_query.edit_message_text.assert_awaited_once()
            text = update.callback_query.edit_message_text.call_args[0][0]
            label, commands = start_plugin.CATEGORIES[key]
            self.assertIn(label, text)
            self.assertIn(commands, text)

    async def test_unknown_category_key_does_not_crash(self):
        update, context = _make_callback_update("menu:not_a_real_category")
        await start_plugin.menu_callback(update, context)
        update.callback_query.answer.assert_awaited()

    async def test_close_deletes_the_message(self):
        update, context = _make_callback_update("close")
        await start_plugin.menu_callback(update, context)
        update.callback_query.delete_message.assert_awaited_once()


class TestPagination(unittest.IsolatedAsyncioTestCase):
    def test_page_count_matches_category_count(self):
        expected_pages = -(-len(start_plugin.CATEGORIES) // 6)  # ceil div
        self.assertEqual(len(start_plugin._PAGES), expected_pages)

    def test_every_category_key_appears_on_exactly_one_page(self):
        seen = []
        for page in start_plugin._PAGES:
            seen.extend(page)
        self.assertEqual(sorted(seen), sorted(start_plugin.CATEGORIES.keys()))
        self.assertEqual(len(seen), len(set(seen)), "a category key appears on more than one page")

    async def test_first_and_last_page_both_render(self):
        update, context = _make_callback_update("page:1")
        await start_plugin.menu_callback(update, context)
        update.callback_query.edit_message_text.assert_awaited_once()

        last = len(start_plugin._PAGES)
        update, context = _make_callback_update(f"page:{last}")
        await start_plugin.menu_callback(update, context)
        update.callback_query.edit_message_text.assert_awaited_once()


class TestNoWholePluginIsMissingFromTheMenu(unittest.TestCase):
    """Not every one of the bot's 226 commands needs its own button (the
    menu is a curated summary, same as /help), but a real command that
    used to have zero mentions anywhere in /menu is exactly the kind of
    gap this round's audit was for. This locks in the specific ones
    found and fixed, so they can't quietly disappear again."""

    def test_previously_unmentioned_real_commands_are_now_present(self):
        all_text = "\n".join(f"{v[0]} {v[1]}" for v in start_plugin.CATEGORIES.values())
        for cmd in ("tts", "qr", "ud", "insta", "yt", "purge", "report", "leave",
                    "dice", "coinflip", "rps", "slots", "tictactoe", "trivia", "guess",
                    "remind", "reminders", "schedule", "announce"):
            self.assertIn(f"/{cmd}", all_text, f"/{cmd} is a real command but isn't mentioned anywhere in /menu")

    def test_games_plugin_has_its_own_category(self):
        self.assertIn("games", start_plugin.CATEGORIES)

    def test_scheduling_has_its_own_category(self):
        self.assertIn("schedule", start_plugin.CATEGORIES)


if __name__ == "__main__":
    unittest.main()
