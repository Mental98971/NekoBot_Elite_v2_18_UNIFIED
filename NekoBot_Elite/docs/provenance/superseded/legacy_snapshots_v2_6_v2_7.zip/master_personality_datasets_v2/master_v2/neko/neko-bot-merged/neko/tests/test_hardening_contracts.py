"""Regression contracts that do not require telegram runtime.

Static, source/data-level checks for invariants that have broken before
and are cheap to guard permanently: catalog size/shape, error-message
hygiene, menu button/panel consistency, superowner command wiring, and
the pytgcalls join-path regression.
"""
from __future__ import annotations

import ast
import json
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class TestCatalogIntegrity(unittest.TestCase):
    def test_skins_and_presets_parse_and_align(self):
        skins_dir = PROJECT_ROOT / "data" / "personality" / "skins"
        presets_dir = PROJECT_ROOT / "data" / "personality" / "presets"
        skins = {p.stem for p in skins_dir.glob("*.json")}
        presets = {p.stem for p in presets_dir.glob("*.json")}
        self.assertGreaterEqual(len(skins), 100)
        self.assertGreaterEqual(len(presets), 100)
        self.assertTrue({"neko", "nanora"} <= skins)
        self.assertTrue({"neko", "nanora"} <= presets)
        for path in list(skins_dir.glob("*.json")) + list(presets_dir.glob("*.json")):
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertIsInstance(data, dict)

    def test_no_stopword_only_preset_keywords(self):
        """Regression guard: a keyword list must not contain bare stopwords
        like 'and' — these previously caused unrelated presets to win
        keyword-matching ties against far more specific presets."""
        stopwords = {"and", "or", "the", "a", "an", "with", "for", "of", "to",
                     "in", "on", "at", "is", "be", "as", "but", "it", "by", "that"}
        presets_dir = PROJECT_ROOT / "data" / "personality" / "presets"
        offenders = []
        for path in presets_dir.glob("*.json"):
            data = json.loads(path.read_text(encoding="utf-8"))
            for kw in data.get("keywords", []):
                if kw.strip().lower() in stopwords:
                    offenders.append((path.stem, kw))
        self.assertEqual(offenders, [], msg=f"stopword keywords found: {offenders}")

    def test_fewshot_bank_shape(self):
        path = PROJECT_ROOT / "data" / "personality" / "dataset" / "fewshot_bank.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        self.assertIn("examples", data)
        self.assertGreaterEqual(len(data["examples"]), 300)


class TestErrorHygieneSource(unittest.TestCase):
    def test_errors_module_defines_leak_markers(self):
        src = (PROJECT_ROOT / "bot" / "core" / "errors.py").read_text(encoding="utf-8")
        for marker in ("gemini", "groq", "openrouter", "api key", "429"):
            self.assertIn(marker, src.lower())
        self.assertIn("def user_facing_error", src)
        self.assertIn("def _looks_like_internal_leak", src)

    def test_ai_plugin_uses_safe_error_helper_not_raw_fstrings(self):
        src = (PROJECT_ROOT / "bot" / "plugins" / "ai.py").read_text(encoding="utf-8")
        self.assertNotIn('f"❌ {e}"', src)
        self.assertNotIn('f"❌ AI Error: {e}"', src)
        self.assertIn("_user_facing_ai_error", src)


class TestMenuContractSource(unittest.TestCase):
    """consolidated's /menu is category-driven (CATEGORIES + _PAGES), not
    the MAIN_MENU/PAGE_N/MENU_PANELS layout other branches used — every
    button must resolve to a real category with real command text, and
    the old generic 'Feature panel for <module>' stub must be gone."""

    def test_every_page_button_has_a_real_category(self):
        src = (PROJECT_ROOT / "bot" / "plugins" / "start.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        categories = None
        for node in tree.body:
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id == "CATEGORIES":
                        categories = ast.literal_eval(node.value)
        self.assertIsInstance(categories, dict)
        self.assertGreaterEqual(len(categories), 10)
        for key, value in categories.items():
            self.assertIsInstance(value, tuple)
            label, detail = value
            self.assertTrue(label.strip())
            self.assertTrue(detail.strip())
        # _KEYS/_PAGES are derived via list(CATEGORIES.keys()) in source, so
        # every page button is a CATEGORIES key by construction — verified
        # directly instead of re-parsing the derived call expression.
        self.assertIn("_KEYS = list(CATEGORIES.keys())", src)

    def test_no_generic_feature_panel_stub(self):
        src = (PROJECT_ROOT / "bot" / "plugins" / "start.py").read_text(encoding="utf-8")
        self.assertNotIn("Feature panel for", src)


class TestPersonaAdminWired(unittest.TestCase):
    def test_superowner_commands_registered(self):
        src = (PROJECT_ROOT / "bot" / "plugins" / "personality.py").read_text(encoding="utf-8")
        for cmd in ("plist", "pshow", "padd", "pdel", "pmerge", "pset", "pdata", "pmeta", "pjson", "preload"):
            self.assertIn(f'"{cmd}"', src, msg=f"missing handler {cmd}")
        self.assertIn("owner_only", src)


class TestMusicJoinNotUsingStreamEnded(unittest.TestCase):
    def test_audio_engine_does_not_pass_stream_audio_ended(self):
        src = (PROJECT_ROOT / "bot" / "services" / "audio_engine.py").read_text(encoding="utf-8")
        self.assertNotIn("stream_type=StreamAudioEnded()", src)
        self.assertIn("def _fresh_audio_url", src)


class TestPersonalityPathsAreCwdIndependent(unittest.TestCase):
    """Regression guard for the cwd-relative path bug: personality data
    loading must resolve against settings.data_dir, never a bare relative
    'data/...' literal, so the bot works regardless of process cwd."""

    def test_no_bare_relative_data_path_literals(self):
        for rel in ("bot/personality/personality.py", "bot/personality/examples.py",
                    "bot/plugins/health.py"):
            src = (PROJECT_ROOT / rel).read_text(encoding="utf-8")
            self.assertNotIn('Path("data/personality', src, msg=f"cwd-relative path literal in {rel}")
            self.assertNotIn("Path('data/personality", src, msg=f"cwd-relative path literal in {rel}")


class TestCatchAllListenerGroupsDontCollide(unittest.TestCase):
    """Regression guard for a near-miss this round: a MessageHandler
    registered with filters.ALL (the broadest possible match) will
    silently shadow any other handler sharing its group number, since
    PTB only runs the first matching handler per group. This codebase
    reserves one group number per such listener (see the comment in
    group_mgmt.py's register()) — this locks in that every
    filters.ALL-based listener still has a group number no other
    filters.ALL-based listener uses, across the whole plugins/ tree."""

    def test_every_filters_all_messagehandler_has_a_unique_group(self):
        plugins_dir = PROJECT_ROOT / "bot" / "plugins"
        seen: dict[int, str] = {}
        for path in sorted(plugins_dir.glob("*.py")):
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                        and node.func.attr == "add_handler"):
                    continue
                if not node.args or not isinstance(node.args[0], ast.Call):
                    continue
                handler_call = node.args[0]
                call_src = ast.unparse(handler_call)
                if "MessageHandler" not in call_src or "filters.ALL" not in call_src:
                    continue
                group_kw = next((kw for kw in node.keywords if kw.arg == "group"), None)
                group_val = ast.literal_eval(group_kw.value) if group_kw else 0
                if group_val in seen:
                    self.fail(
                        f"group={group_val} used by both {seen[group_val]} and "
                        f"{path.name} for a filters.ALL MessageHandler — the second "
                        "one will silently never run for any update the first one matches"
                    )
                seen[group_val] = path.name
        self.assertGreater(len(seen), 0, "expected at least one filters.ALL listener to exist")


if __name__ == "__main__":
    unittest.main()
