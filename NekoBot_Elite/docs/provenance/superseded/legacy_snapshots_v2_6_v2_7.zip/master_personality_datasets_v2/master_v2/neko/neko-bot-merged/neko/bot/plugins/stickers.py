"""
Sticker pack management — real Telegram Bot API sticker-set operations
(create/add/pack-info), not a placeholder. Each user gets one personal
pack, named deterministically from their own ID so no extra storage is
needed to remember "whose pack is which".
"""
from __future__ import annotations

import io

from PIL import Image
from telegram import InputSticker, Update
from telegram.error import BadRequest
from telegram.ext import ContextTypes, CommandHandler

from bot.core.errors import safe_handler, user_facing_error

STICKER_EMOJI_DEFAULT = "🙂"


def _pack_name(user_id: int, bot_username: str) -> str:
    # Telegram requires sticker-set names to end in _by_<bot_username>
    # and to start with a letter — "a" prefix guarantees that even for
    # numeric-leading cases, and keeps the name deterministic per user.
    return f"a{user_id}_by_{bot_username}"


async def _resize_for_sticker(image_bytes: bytes) -> bytes:
    """Telegram static stickers need PNG/WEBP with the longer side at
    exactly 512px. Resize losslessly (keeping aspect ratio) rather than
    rejecting whatever the user sent."""
    img = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
    w, h = img.size
    scale = 512 / max(w, h)
    img = img.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.LANCZOS)
    out = io.BytesIO()
    img.save(out, format="PNG")
    return out.getvalue()


async def _get_source_image_bytes(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bytes | None:
    reply = update.message.reply_to_message
    if not reply:
        return None
    file_obj = None
    if reply.photo:
        file_obj = await context.bot.get_file(reply.photo[-1].file_id)
    elif reply.sticker and not reply.sticker.is_animated and not reply.sticker.is_video:
        file_obj = await context.bot.get_file(reply.sticker.file_id)
    elif reply.document and (reply.document.mime_type or "").startswith("image/"):
        file_obj = await context.bot.get_file(reply.document.file_id)
    if not file_obj:
        return None
    buf = io.BytesIO()
    await file_obj.download_to_memory(out=buf)
    return buf.getvalue()


@safe_handler
async def kang_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/kang [emoji] — reply to a photo/static sticker/image file to add it
    to your own personal sticker pack (created automatically on first use)."""
    raw_bytes = await _get_source_image_bytes(update, context)
    if raw_bytes is None:
        await update.message.reply_text(
            "Reply to a photo, a static sticker, or an image file with /kang to add it to your pack."
        )
        return

    emoji = context.args[0] if context.args and len(context.args[0]) <= 4 else STICKER_EMOJI_DEFAULT
    user = update.effective_user
    bot_username = context.bot.username
    pack_name = _pack_name(user.id, bot_username)
    pack_title = f"{user.first_name or user.username or user.id}'s pack"

    msg = await update.message.reply_text("🏷 Kanging...")
    try:
        png_bytes = await _resize_for_sticker(raw_bytes)
        sticker = InputSticker(sticker=png_bytes, emoji_list=[emoji], format="static")

        try:
            await context.bot.get_sticker_set(pack_name)
            pack_exists = True
        except BadRequest:
            pack_exists = False

        if pack_exists:
            await context.bot.add_sticker_to_set(user_id=user.id, name=pack_name, sticker=sticker)
        else:
            await context.bot.create_new_sticker_set(
                user_id=user.id, name=pack_name, title=pack_title[:64], stickers=[sticker]
            )

        await msg.edit_text(f"✅ Added! Pack: https://t.me/addstickers/{pack_name}")
    except BadRequest as e:
        # Telegram's own validation messages here are already user-safe
        # (e.g. "STICKERSET_INVALID", "invalid sticker emojis") — pass
        # them through rather than a generic fallback.
        await msg.edit_text(f"❌ Telegram rejected that: {e.message}")
    except Exception as e:
        await msg.edit_text(user_facing_error(e, fallback="❌ Couldn't add that sticker. Try a different image."))


@safe_handler
async def packinfo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/packinfo — link to your own /kang pack, if you have one yet."""
    user = update.effective_user
    bot_username = context.bot.username
    pack_name = _pack_name(user.id, bot_username)
    try:
        pack = await context.bot.get_sticker_set(pack_name)
        await update.message.reply_text(
            f"🏷 Your pack: https://t.me/addstickers/{pack_name}\n{len(pack.stickers)} sticker(s) so far."
        )
    except BadRequest:
        await update.message.reply_text("You don't have a pack yet — reply to an image with /kang to start one.")


def register(app):
    app.add_handler(CommandHandler("kang", kang_cmd))
    app.add_handler(CommandHandler("packinfo", packinfo_cmd))
